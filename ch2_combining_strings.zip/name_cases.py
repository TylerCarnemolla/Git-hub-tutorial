
dog_breed = "labrador"
print(dog_breed.title())
print(dog_breed.upper())
print(dog_breed.lower())