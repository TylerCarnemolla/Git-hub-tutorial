message="hello python world!"
print(message)

message= "Hello python crash course world!"
print(message)

name= "ada lovelace"
print(name.title())
