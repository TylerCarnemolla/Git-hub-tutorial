name = "ada lovelace"
print(name.title())

print(name.upper())

print(name.lower())

first_name= "tyler"
last_name = "Carnemolla"
full_name = "Tyler Carnemolla"
print(full_name.title())
full_name = first_name + " "+ last_name
print(full_name)

name="tommy"
print("Hello " +name + ", would you like to meet up today?")

dog_breed = "labrador"
print(dog_breed.title())
print(dog_breed.upper())
print(dog_breed.lower())

age="88"
message= "happy "+ age + "th Birthday!"

message = "happy "+ str(age) + "th Birthday"
print(message)
phrase = 'john\'s shirt is green'
print(phrase)
type(phrase)
num1=1
num2=2
sum=