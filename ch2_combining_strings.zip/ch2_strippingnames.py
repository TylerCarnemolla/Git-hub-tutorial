name = "            Albert         "
print(name.rstrip())
print(name.lstrip())
print(name.strip())