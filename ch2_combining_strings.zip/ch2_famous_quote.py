name="Bert Kreischer"
Quote= "'Skydiving is fascinating, the best part is cruising in the air and realizing that the dice has been thrown and your either going to die or not. Its a very hopeless feeling but so freeing.'"
print(name + " once said, "+ Quote)