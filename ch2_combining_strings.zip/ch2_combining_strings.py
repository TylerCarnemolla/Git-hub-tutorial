name="tommy"
print("Hello " +name + ", would you like to meet up today?")